/****************************************************************************************************
*
*	TRABALHO 1 - Sistemas de Computação
*	Professor: Luiz Fernando Bessa Seibel
*	07/10/2015
*
*	Aluno:	João Pedro Garcia 1211768
*
*	O programa lê, na ordem dada, as seguintes informações de um arquivo "entrada.txt" :
*
*		1. A palavra exec indicando mais um programa a ser executado ;
*
*		2. O nome do programa a ser executado, o nome do programa é uma string sempre de nome 
*       programaN, onde n é um numero inteiro de 1 a 7 
*       
*       3.(Não obrigatorio) Novamente le uma string, caso seja igual a "prioridade=" ele 
*       identifica o tipo do escalonador como prioridade. Caso seja exec volta ao passo 1
*       
*       4.(Não obrigatorio) Um inteiro dizendo a ordem de prioridade 1 mais alta e 7 mais baixa
*
*	Apos ler e armazenar as informações, o programa chama executa os processos na ordem cor-
*	reta, conforme especificado no enunciado do trabalho. 
*
****************************************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <sys/types.h>
#include <signal.h>

#define MAX_NUM_PROGRAMAS	7

/***************************************************************************************************/
//Estruturas de dados auxiliares.
struct infoProcesso{
	char nome[20]; /* Nome do programa referente ao processo */
	int pid;       /* PID do processo */
	int p;         /* Prioridade do processo (NULL caso o escalonador não seja por prioridades) */
}; typedef struct infoProcesso InfoProcesso ;

/***************************************************************************************************/

int interpretador(FILE * fp1, FILE * fp2, InfoProcesso vetorInfo[], char * tipo, int * numProgramas);
int criaProcesso(int * pidProcesso, int posicao, char * nomeProcesso) ;
int escalonador(FILE * fp2, InfoProcesso vetorInfo[], char * tipo, int numProgramas) ;
int criaPrograma(int n) ;
				
/***************************************************************************************************/

int main (void)
{
	InfoProcesso  vetorInfo[MAX_NUM_PROGRAMAS] ;
	char tipo[12] ;
	int numProgramas, retorno ;
    
	FILE * fp1 = fopen ("entrada.txt", "r") ; /* Abertura de arquivo de entrada */
	FILE * fp2 = fopen ("saida.txt", "w") ;   /* Abertura de arquivo de saida   */
    
	if (fp1 == NULL || fp2 == NULL)           /* Teste de validação de abertura */
	{
		fprintf (fp2, "Erro na abertura de arquivo...") ;
		return 1 ;
	}

	retorno = interpretador (fp1, fp2, vetorInfo, tipo, &numProgramas) ;
    printf("Tipo Escalonamento: %s\n", tipo);

	if (retorno != 0)
	{
		fprintf (fp2, "Erro no interpretador\n") ;
        return 1 ;
	}

	escalonador(fp2, vetorInfo, tipo, numProgramas) ;
	
	fclose (fp1) ;
	fclose (fp2) ;
	return 0 ;
}



/****************************************************************************************************
* 
*	Função: interpretador
*				
****************************************************************************************************/

int interpretador (	FILE * fp1,	FILE * fp2, InfoProcesso vetorInfo[], char * tipo,	int * numProgramas)
{

	int	ret, i, numProgAtual; /* ret armazena retorno da função escalonador	*/
    char exec[12];            /* auxiliar na leitura do arquivo lendo "exec" ou "prioridade="*/
    
    strcpy(tipo, "RR");       /*Inicialmente determina o tipo do escalonador como RR*/
    
    i = 0;                    /* Zera as variaveis antes de entrar no While*/
    *numProgramas = 0;
    
    while(fscanf (fp1, "%s", exec) == 1){ /* inicia a leitura do arquivo entrada */
        if(!strcmp(exec, "exec")){
            fscanf(fp1,"%s", vetorInfo[i].nome);
            (*numProgramas)++;
            i++;
        }
        else{
            fscanf(fp1,"%d", &vetorInfo[i-1].p);
            strcpy(tipo, "PRIORIDADE"); /* Caso leia prioridade determina o tipo de escalonador para Prioridade */
        }
    }
	
    if (!strcmp (tipo, "RR")){ /* Caso ROUND-ROBIN */
        for (i = 0; i < *numProgramas; i++){
		 	ret = criaProcesso(&(vetorInfo[i].pid), i, vetorInfo[i].nome);
        
		 	if ( ret == -1 ){
		 		fprintf (fp2, "Não foi possivel criar o processo ou o programa %s nao existe...\n", vetorInfo[i].nome) ;
		 		return -1 ;
		 	}
		}
	}

    else if (!strcmp (tipo, "PRIORIDADE")){ /* Caso LISTA DE PRIORIDADES */
		for (i = 0 ; i < *numProgramas; i++){
		 	ret = criaProcesso (&(vetorInfo[i].pid), i, vetorInfo[i].nome);
		 	
		 	if ( ret == -1 ){
		 		fprintf (fp2, "Não foi possivel criar o processo ou o programa %s nao existe...\n", vetorInfo[i].nome) ;
		 		return -1 ;	
		 	}
			else if ( vetorInfo[i].p < 1 || vetorInfo[i].p > 7){
		 		fprintf (fp2, "Prioridade invalida...\n") ;
		 		return -1 ;	
		 	}
		}

	}
	return 0 ;
}



/****************************************************************************************************
* 
*	Função: criaProcesso
*				
****************************************************************************************************/

int criaProcesso (int * pidProcesso, int posicao, char * nomeProcesso)
{
	int pid ;
    
	if(!strcmp(nomeProcesso, "programa1"))
		pid = criaPrograma(1) ;
		
	else if(!strcmp(nomeProcesso, "programa2"))
		pid = criaPrograma(2) ;
	
	else if(!strcmp(nomeProcesso, "programa3"))
		pid = criaPrograma(3) ;
		
	else if(!strcmp(nomeProcesso, "programa4"))
		pid = criaPrograma(4) ;
		
	else if(!strcmp(nomeProcesso, "programa5"))
		pid = criaPrograma(5) ;
    
    else if(!strcmp (nomeProcesso, "programa6"))
        pid = criaPrograma(6) ;
    
    else if(!strcmp (nomeProcesso, "programa7" ))
        pid = criaPrograma(7) ;
		
	else
	{
        printf("Nome do programa invalido. Não foi possivel criar o processo");
		return -1 ;
	}
	
	if ( pid == -1 )
	{
        printf("PID -1. Não foi possivel criar o processo");
		return -1 ;
	}
	
	*pidProcesso = pid ;
	return 0 ;
}



/****************************************************************************************************
* 
*	Funções: criaPrograma
*
*	Retorno: 
*		pid - pid do processo criado
*		0 - quando não consegue executar o fork
*				
****************************************************************************************************/

int criaPrograma (int n)
{
	int pid ;
    char nomePrograma[10] = "programa";
    sprintf(nomePrograma, "programa%d", n);
	
	pid = fork ()	; /* Executa o fork */

    if ( pid < 0 ){ /* Com problemas no fork retorna erro */
        return 0 ;
    }
    
    else if ( pid != 0 ){ /* PAI */
		kill ( pid, SIGSTOP ) ;	/* Pausa processo filho no início da execução	*/
		return pid ; 			/* Retorna o pid do filho					*/
	}
	
	else{ /* FILHO */
		execl(nomePrograma, "nada", NULL) ;
	}
	
	return 0 ;
}


/****************************************************************************************************
* 
*	Função: escalonador
*				
****************************************************************************************************/

int escalonador (FILE * fp2, InfoProcesso vetorInfo[], char * tipo, int numProgramas) 
{
	int aux [MAX_NUM_PROGRAMAS] ;
	int i, j, k, pid, temp, status ;
	
    if ( !strcmp (tipo, "RR") ) /* Caso ROUND-ROBIN */
    {
		temp = numProgramas;
		fprintf (fp2, "Escalonamento escolhido: ROUND-ROBIN\n") ;
		
		for (i = 0 ; i < numProgramas ; i++)
			aux[i] = vetorInfo[i].pid ;
		
		while (numProgramas) /* Enquanto ainda existirem programas a serem executados */
		{
			for (i = 0; i < temp; i++)
			{
				if (aux[i] == 0)
					continue;
					
				fprintf (fp2, "Executando programa %s...\n", vetorInfo[i].nome) ;
				kill (aux[i], SIGCONT) ;
				sleep (1) ; /* Tempo de execução de cada processo = 1 segundo */
				kill (aux[i], SIGSTOP) ;
				
				pid = waitpid (aux[i], &status, WNOHANG) ;
				
				if ( pid > 0 && WIFEXITED(status) )
				{
					fprintf (fp2 ,"Programa %s terminou sua execução...\n", vetorInfo[i].nome) ;
					aux[i] = 0 ;
					numProgramas-- ;
					continue ;
				}
				
				fprintf (fp2, "Pausando programa %s...\n", vetorInfo[i].nome) ;
			}
		}
	} /* Final caso ROUND-ROBIN */

	else if ( !strcmp (tipo, "PRIORIDADE") ) /* Caso LISTA DE PRIORIDADES */
    {printf("entra na piori");
		fprintf (fp2, "Escalonamento escolhido: LISTA DE PRIORIDADES\n") ;
		
		for (i = 0; i < numProgramas; i++) /* Preenche vetor aux com as prioridades */
			aux[i] = vetorInfo[i].p;

		for (i = 0 , k = numProgramas-1 ; i < numProgramas ; i++) /* Ordena vetor auxiliar */
		{
			for (j = 0 ; j < k ; j++) 
			{
				if (aux[j] > aux[j+1]) 
				{
					temp = aux[j] ;
					aux[j] = aux[j+1] ;
					aux[j+1] = temp ;
				}
			}
			k-- ;
		}

		for (i = 0 ; i < numProgramas ; i++) 
		{
			for (j = 0 ; j < numProgramas ; j++) 
			{
				if (aux[i] == vetorInfo[j].p) 
				{
					fprintf (fp2, "Inicio da execucao do programa %s\n", vetorInfo[j].nome) ;
					kill(vetorInfo[j].pid, SIGCONT) ;
					waitpid(vetorInfo[j].pid, &status, 0) ;
					fprintf (fp2, "Fim da execucao do programa %s\n", vetorInfo[j].nome) ;
				}
			}
		}
	} /* Final caso LISTA DE PRIORIDADES */
	return 0;
}

